# SilverBot
SilverBot Is A Unbranded Lobby Bot That Is Awesome For Trolling

# Info

For The Default Skin You Can [Join Our Discord](discord.gg/hmXa5cQCJH) Server And Do The Command ?item item name to get the ID of that cosmetic and put in the Settings.json where it goes

# Support

For Any More Support [Join Our Discord](discord.gg/hmXa5cQCJH)