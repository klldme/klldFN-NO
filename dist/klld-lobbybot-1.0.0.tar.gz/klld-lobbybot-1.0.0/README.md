# klld
klld Is A Unbranded Lobby Bot That Is Awesome For Trolling

# Info

For The Default Skin You Can [Join Our Discord](www.klld.tk) Server And Do The Command ?item item name to get the ID of that cosmetic and put in the Settings.json where it goes

# Support

For Any More Support [Join Our Discord](www.klld.tk)